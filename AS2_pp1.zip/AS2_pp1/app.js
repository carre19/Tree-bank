require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const axios = require('axios');
const app = express();

const personaRoutes = require('./routes/personaRoutes');
const tablaController = require('./controllers/tablaController');
const syncRoutes = require('./routes/sync');
const { ejecutarSync } = require('./routes/sync'); // exportamos la función

// Middlewares PRIMERO
app.use(cors());
app.use(express.json());

// Rutas
app.use('/api', personaRoutes);
app.use('/api', syncRoutes);
app.get('/api/tablas/:tabla', tablaController.obtenerTabla);

// 404
app.use((req, res) => {
    res.status(404).json({ error: "La ruta solicitada no existe." });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log('\x1b[32m%s\x1b[0m', `--- Servidor levantado en puerto ${PORT} ---`);
    if (!process.env.CENTRAL_BANK_API_KEY) {
        console.log('\x1b[33m%s\x1b[0m', "⚠️ Falta la API KEY del Banco Central en .env");
    }
});

// ✅ MEJORA 1: Sync automático cada 15 minutos
cron.schedule('*/15 * * * *', async () => {
    console.log('🔄 Sync automático ejecutándose...');
    await ejecutarSync();
});