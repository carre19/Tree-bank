const axios = require('axios');
const Persona = require('../models/personaModel');

exports.crearPersona = async (req, res) => {
    const { nombre, apellido, dni } = req.body;
    try {
        const respuestaCentral = await axios.post(`${process.env.CENTRAL_BANK_URL}/persons`, {
            nombre, apellido, dni
        }, {
            headers: {
                'x-api-key': process.env.CENTRAL_BANK_API_KEY,
                'x-environment': process.env.X_ENVIRONMENT
            }
        });

        const cbuProfe = respuestaCentral.data.cbu;
        const nuevaCuenta = await Persona.createConCuenta({ nombre, apellido, dni, cbu: cbuProfe });

        res.status(201).json({
            mensaje: "Cliente y cuenta registrados con éxito",
            cbu: cbuProfe,
            datos: nuevaCuenta
        });
    } catch (error) {
        const detalle = error.response ? error.response.data : error.message;
        res.status(500).json({ error: "No se pudo completar el registro", detalle });
    }
};

exports.realizarTransferencia = async (req, res) => {
    const { cbu_origen, cbu_destino, monto, descripcion } = req.body;
    try {
        const cuentaOrigen = await Persona.getByCbu(cbu_origen);
        if (!cuentaOrigen) {
            return res.status(404).json({ error: 'El CBU de origen no pertenece a este banco' });
        }

        const respuestaCentral = await axios.post(`${process.env.CENTRAL_BANK_URL}/transactions`, {
            cbuOrigen: cbu_origen,
            cbuDestino: cbu_destino,
            importe: monto,
            saldoOrigen: cuentaOrigen.saldo
        }, {
            headers: {
                'x-api-key': process.env.CENTRAL_BANK_API_KEY,
                'x-environment': process.env.X_ENVIRONMENT
            }
        });

        if (respuestaCentral.status === 201) {
            await Persona.transferirSaldo(cbu_origen, cbu_destino, monto);

            // Egreso del origen
            await Persona.registrarMovimiento({
                id_cuenta: cuentaOrigen.id_cuenta,
                tipo_movimiento: 'TRANSFERENCIA_EGRESO',
                monto,
                descripcion: descripcion || 'Transferencia enviada'
            });

            // ✅ MEJORA 3: Ingreso en destino si es cuenta interna
            const cuentaDestino = await Persona.getByCbu(cbu_destino);
            if (cuentaDestino) {
                await Persona.registrarMovimiento({
                    id_cuenta: cuentaDestino.id_cuenta,
                    tipo_movimiento: 'TRANSFERENCIA_INGRESO',
                    monto,
                    descripcion: descripcion || 'Transferencia recibida'
                });
            }

            res.status(201).json({
                mensaje: 'Transferencia realizada con éxito',
                ticket: respuestaCentral.data
            });
        }
    } catch (error) {
        const detalle = error.response ? error.response.data : error.message;
        res.status(400).json({ error: 'La transferencia fue rechazada', motivo: detalle });
    }
};

exports.obtenerMovimientos = async (req, res) => {
    try {
        const { idCuenta } = req.params;
        const movimientos = await Persona.getMovimientos(idCuenta);
        res.json(movimientos);
    } catch (error) {
        res.status(500).json({ error: "Error al obtener historial", detalle: error.message });
    }
};

exports.obtenerPersonas = async (req, res) => {
    try {
        const personas = await Persona.getAll();
        res.json(personas);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.obtenerRoles = async (req, res) => {
    try {
        const roles = await Persona.getRoles(req.params.id);
        res.json(roles);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.obtenerProductos = async (req, res) => {
    try {
        const productos = await Persona.getProductos(req.params.id);
        res.json(productos);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};