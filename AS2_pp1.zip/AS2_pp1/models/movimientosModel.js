const { createClient } = require('@supabase/supabase-js');
const supabaseUrl = 'https://znoklmhspgchdbcmgyqj.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpub2tsbWhzcGdjaGRiY21neXFqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY4MTIzMTQsImV4cCI6MjA5MjM4ODMxNH0.PEzUhi4b0DehxooBiagixDEcqO_TygtWav7OQKWBIj4';
const supabase = createClient(supabaseUrl, supabaseKey);

const Movimiento = {
    // Función para insertar un movimiento
    async crear(datos) {
        const { data, error } = await supabase
            .from('movimientos')
            .insert([datos]);
        return { data, error };
    },

    // Función para actualizar el saldo de la cuenta
    async actualizarSaldo(id_cuenta, nuevoSaldo) {
        const { data, error } = await supabase
            .from('cuentas_bancarias')
            .update({ saldo: nuevoSaldo })
            .eq('id_cuenta', id_cuenta);
        return { data, error };
    }
};

module.exports = Movimiento;