 async function CrearCliente(event){
    event.preventDefault(); // evita que recargue la página
      const cliente = {
        nombre: document.getElementById("nombre").value,
        apellido: document.getElementById("apellido").value,
        dni: document.getElementById("dni").value,
        producto: document.getElementById("productos").value,
        saldo: document.getElementById("saldo").value,
        estado: document.getElementById("estado").value,
        limite_compra: null
    }
console.log("carga exitosa",cliente)

 const resultado = await fetch("http://localhost:3001/api/personas", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(cliente)
    });

    const data = await resultado.json();
    console.log("cliente cargado con exito", data)

};




